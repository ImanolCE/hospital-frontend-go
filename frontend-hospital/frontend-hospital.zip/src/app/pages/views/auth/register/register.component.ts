import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';

import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../../../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, InputTextModule, ButtonModule, RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent {
  username: string = '';
  apellido: string = '';
  email: string = '';
  password: string = '';
  confirmPassword: string = '';

  constructor(private auth: AuthService, private router: Router) {}

  onRegister() {
    this.auth.register({
      nombre: this.username,
      apellido: this.apellido,
      correo: this.email,
      password: this.password,
      tipo_usuario: 'paciente' // rol por defecto
    }).subscribe({
      next: () => this.router.navigate(['/auth/login']),
      error: err => console.error('Registro fallido', err)
    });
  }
}

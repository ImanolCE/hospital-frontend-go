import { Routes } from '@angular/router';
import { LoginComponent } from './pages/views/auth/login/login.component';
import { RegisterComponent } from './pages/views/auth/register/register.component';

import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: 'auth/login',    component: LoginComponent },
  { path: 'auth/register', component: RegisterComponent },

  { 
    path: 'paciente',
    canActivate: [AuthGuard],
    data: { permisos: ['ver_dashboard','ver_consultas','ver_expediente'] },
    loadComponent: () => import('./pages/views/paciente/dashboard/dashboard.component')
                         .then(m => m.DashboardPacienteComponent),
  },
  { 
    path: 'enfermera',
    canActivate: [AuthGuard],
    data: { permisos: ['ver_dashboard','ver_horarios','ver_consultorios'] },
    loadComponent: () => import('./pages/views/enfermera/dashboard/dashboard.component')
                         .then(m => m.DashboardEnfermeraComponent),
  },
  { 
    path: 'medico',
    canActivate: [AuthGuard],
    data: { permisos: ['ver_dashboard','ver_consultas','ver_horarios','ver_expediente'] },
    loadComponent: () => import('./pages/views/medico/dashboard/dashboard.component')
                         .then(m => m.DashboardMedicoComponent),
  },

  // ← siempre al final
  { path: '**', redirectTo: 'auth/login' },
];

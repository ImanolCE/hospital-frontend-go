// src/app/services/auth.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { tap, map, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';

// Interfaz para la respuesta del login
interface LoginResponse {
  access_token: string;
  refresh_token: string;
}

interface RegisterResponse {
  message: string;
  otpauth_url: string;
}


interface WrappedRes<T> {
  data: T[];
  intCode: string;
  statusCode: number;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:3000';  // Ajusta si cambias de URL
  private tokenKey = 'access_token';
  private refreshKey = 'refresh_token';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  
  // Login: hace POST a /login y guarda tokens en localStorage.
   // Devuelve void pero podría extenderse para devolver datos si quieres.
  
  
  login(email: string, password: string, otp: string): Observable<LoginResponse> {
    return this.http
      .post<WrappedRes<LoginResponse>>(
        `${this.apiUrl}/login`,
        { correo: email, password, otp  }
      )
      .pipe(
        tap(res => {
          const { access_token, refresh_token } = res.data[0];
          localStorage.setItem(this.tokenKey, access_token);
          localStorage.setItem(this.refreshKey, refresh_token);
        }),
        map(res => res.data[0]),       // ¡IMPORTANTE! ahora devolvemos el objeto con tokens
        catchError(this.handleError)
      );
  }

   // Registro: hace POST a /users con los datos necesarios.
   
  register(userData: {
    nombre: string;
    apellido: string;
    correo: string;
    password: string;
    tipo_usuario: string;
  }): Observable<RegisterResponse> {
    return this.http
      .post<WrappedRes<RegisterResponse>>(`${this.apiUrl}/usuarios`, userData)
      .pipe(
        map(res => res.data[0]), // ← extraemos el primer objeto de "data"
        catchError(this.handleError)
      );
  }


  
   // Refresh token: usa el refresh token para obtener nuevos tokens.
  
   refreshToken(): Observable<LoginResponse> {
    const rt = localStorage.getItem(this.refreshKey);
    return this.http
      .post<WrappedRes<LoginResponse>>(
        `${this.apiUrl}/refresh`,
        { refresh_token: rt }
      )
      .pipe(
        tap(res => {
          const { access_token, refresh_token } = res.data[0];
          localStorage.setItem(this.tokenKey, access_token);
          localStorage.setItem(this.refreshKey, refresh_token);
        }),
        map(res => res.data[0]),
        catchError(this.handleError)
      );
  }

   // Logout: limpia los tokens y redirige al login.
   
  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.refreshKey);
    this.router.navigate(['/auth/login']);
  }

  
   // Recupera el access token.
   
  getAccessToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  
   // Extrae y devuelve el payload completo del JWT como objeto,
   // o null si hay cualquier error.
   
  getPayload(): any | null {
    const token = this.getAccessToken();
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    try {
      const payloadJson = atob(parts[1]);
      return JSON.parse(payloadJson);
    } catch {
      return null;
    }
  }

  
  //  Devuelve un objeto con los datos del usuario embebidos en el token
  //     (p.ej. id, nombre, correo, tipo_usuario, permisos).
   
  getUser(): any | null {
    const payload = this.getPayload();
    // Ajusta aquí según la estructura de tu JWT:
    // por ejemplo payload.sub, payload.id_usuario, payload.user, etc.
    return payload?.user || payload;
  }

  
   // Extrae el ID del usuario desde el payload.
   
  getUserId(): number | null {
    const payload = this.getPayload();
    // Si tu payload usa "sub" o "id_usuario", ajústalo:
    return payload?.sub ?? payload?.id_usuario ?? null;
  }

  
  // Extrae el rol (tipo_usuario) del payload.
   
  getUserRole(): string | null {
    const payload = this.getPayload();
    return payload?.tipo_usuario ?? payload?.rol ?? null;
  }

  
  //  Extrae la lista de permisos del token.
   
  getPermisos(): string[] {
    const payload = this.getPayload();
    if (!payload || !Array.isArray(payload.permisos)) {
      return [];
    }
    return payload.permisos;
  }

  
  //  Manejador central de errores HTTP.
   
  private handleError(error: HttpErrorResponse) {
    console.error('AuthService error', error);
    // Aquí podrías procesar distintos códigos de error y mostrar mensajes.
    return throwError(() => error);
  }

  // Verifica si el usuario tiene un permiso específico
hasPermiso(nombre: string): boolean {
  return this.getPermisos().includes(nombre);
}

activarMFA(correo: string, otp: string): Observable<any> {
  return this.http.post(`${this.apiUrl}/activar-mfa`, { correo, otp }).pipe(
    catchError(this.handleError)
  );
}


}

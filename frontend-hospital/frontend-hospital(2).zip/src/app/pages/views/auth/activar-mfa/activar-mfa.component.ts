import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-activar-mfa',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, RouterModule],
  templateUrl: './activar-mfa.component.html',
  styleUrls: ['./activar-mfa.component.css']
})
export class ActivarMFAComponent {
  correo: string = '';
  otp: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  activarMFA() {
    this.http.post('http://localhost:3000/activar-mfa', {
      correo: this.correo,
      otp: this.otp
    }).subscribe({
      next: (res: any) => {
        alert('MFA activado correctamente');
        this.router.navigate(['/auth/login']);
      },
      error: err => {
        alert('Error al activar MFA: ' + (err.error?.error || err.message));
      }
    });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ConsultaService {
  private apiUrl = 'http://localhost:3000/consultas';

  constructor(private http: HttpClient, private auth: AuthService) {}

  obtenerConsultasPaciente(idPaciente: string): Observable<any[]> {
    const headers = new HttpHeaders({
      Authorization: this.auth.addAuthHeader()
    });

    return this.http
      .get<any[]>(`${this.apiUrl}/paciente/${idPaciente}`, { headers })
      .pipe(map((res: any) => res.data));
  }
}

import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { AuthService } from '../../../services/auth.service';
import { ConsultaService } from '../../../services/consulta.service';
import { Card } from "primeng/card";

@Component({
  standalone: true,
  selector: 'app-dashboard-paciente',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  imports: [CommonModule, PanelModule, TableModule, ButtonModule, Card],
})

export class DashboardPacienteComponent implements OnInit {
  auth = inject(AuthService);
  consultaService = inject(ConsultaService);

  consultas: any[] = [];
  mostrarConsultas = false;
  permisos: string[] = [];

  ngOnInit(): void {
    this.permisos = this.auth.getPermisos(); // ← permisos vienen del JWT
  }

  verConsultas() {
  const idPaciente = this.auth.getUserId(); // debe retornar un número
    console.log('idPaciente:', idPaciente);

   if (idPaciente !== null) {
  this.consultaService.obtenerConsultasPaciente(idPaciente.toString()).subscribe({
    next: (data) => {
      this.consultas = data;
      this.mostrarConsultas = true;
    },
    error: (err) => {
      console.error('Error al obtener consultas', err);
    }
  });
} else {
  console.error('ID de paciente no válido');
}

  }

}

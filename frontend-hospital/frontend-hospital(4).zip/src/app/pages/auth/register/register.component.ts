// src/app/pages/views/auth/register/register.component.ts

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { Router } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
//import { SharedModule } from '../../../shared.module'

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    InputTextModule,
    PasswordModule,
    ButtonModule,
    CardModule,
    
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  // Datos de registro
  username = '';
  apellido = '';
  email = '';
  password = '';
  confirmPassword = '';

  // MFA recovery
  otpauthUrl: string | null = null;
  qrUrl: string | null = null;
  otp = '';

  // Control de pasos en la UI
  paso: 1 | 2 = 1;
  loading = false;

  constructor(private auth: AuthService, private router: Router) {}

  /** Paso 1: Registrarse */
  onRegister(): void {
    if (this.password !== this.confirmPassword) {
      return alert('Las contraseñas no coinciden');
    }
    this.loading = true;

    const payload = {
      nombre: this.username,
      apellido: this.apellido,
      correo: this.email,
      password: this.password,
      tipo_usuario: 'paciente'
    };

    this.auth.register(payload).subscribe({
      next: res => {
        // La API devuelve { message, otpauth_url }
        this.otpauthUrl = res.otpauth_url;
        // Generamos la imagen del QR
        this.qrUrl = `https://api.qrserver.com/v1/create-qr-code/` +
                     `?data=${encodeURIComponent(this.otpauthUrl)}&size=200x200`;
        this.paso = 2;         // avanzamos al paso 2: activar MFA
        this.loading = false;
      },
      error: err => {
        this.loading = false;
        console.error('Registro fallido', err);
        alert('Registro fallido: ' + (err.error?.error || err.statusText));
      }
    });
  }

  /** Paso 2: Activar MFA sin JWT (flujo público) */
  activateRecovery(): void {
    if (!this.otp) {
      return alert('Introduce el código OTP que aparece en tu app');
    }
    this.loading = true;

    this.auth.activateRecoveryMfa(this.email, this.otp).subscribe({
      next: ({ message }) => {
        this.loading = false;
        alert(message);           // "MFA activado correctamente"
        this.router.navigate(['/auth/login']);
      },
      error: err => {
        this.loading = false;
        console.error('Error al activar MFA', err);
        alert('Error al activar MFA: ' + (err.error?.error || err.statusText));
      }
    });
  }

  /** Volver al login manualmente */
  irAlLogin(): void {
    this.router.navigate(['/auth/login']);
  }
}
